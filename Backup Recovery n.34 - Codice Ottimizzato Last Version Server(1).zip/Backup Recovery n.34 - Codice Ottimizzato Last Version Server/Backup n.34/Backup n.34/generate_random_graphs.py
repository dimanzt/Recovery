__author__ = 'ciavarellas'

from my_lib import *

generate_erdos_renyi_graph(100,1.0)